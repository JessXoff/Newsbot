import test from "node:test";
import assert from "node:assert/strict";
import {
  meetsEditorialThreshold,
  rankAndClusterArticles,
  titleSimilarity,
} from "../editorial.js";

const strongAcademic = {
  decision: "ACCEPT_ACADEMIC",
  relevance: 5,
  credibility: 5,
  substance: 4,
  qualityScore: 88,
  confidence: 0.94,
  crankRisk: false,
  riskSignals: [],
};

test("the deterministic editorial floor accepts both intended publication paths", () => {
  assert.equal(meetsEditorialThreshold(strongAcademic), true);
  assert.equal(
    meetsEditorialThreshold({
      ...strongAcademic,
      decision: "ACCEPT_CONTEMPORARY_LITURGICAL",
      credibility: 3,
      qualityScore: 72,
    }),
    true
  );
});

test("rejections and weak model accepts cannot bypass the editorial floor", () => {
  assert.equal(
    meetsEditorialThreshold({ ...strongAcademic, decision: "REJECT_CRANK" }),
    false
  );
  assert.equal(
    meetsEditorialThreshold({
      ...strongAcademic,
      crankRisk: true,
      riskSignals: ["fabricated translation claim"],
    }),
    false
  );
  assert.equal(
    meetsEditorialThreshold({ ...strongAcademic, credibility: 3 }),
    false
  );
  assert.equal(
    meetsEditorialThreshold({
      ...strongAcademic,
      decision: "ACCEPT_CONTEMPORARY_LITURGICAL",
      confidence: 0.6,
    }),
    false
  );
});

test("similar coverage is clustered and the strongest item represents the story", () => {
  const now = new Date("2026-08-16T12:00:00Z");
  const weaker = {
    ...strongAcademic,
    link: "google:1",
    publisherLink: "https://example.com/story?utm_source=rss",
    title: "Museum unveils newly restored temple of Ishtar - Local Wire",
    source: "Local Wire",
    snippet: "",
    pubDate: "2026-08-15T12:00:00Z",
    reason: "museum reporting",
    discoveredAt: now.toISOString(),
    qualityScore: 76,
  };
  const stronger = {
    ...weaker,
    link: "google:2",
    publisherLink: "https://example.com/story",
    title: "Museum unveils newly restored temple of Ishtar - University News",
    source: "University News",
    qualityScore: 92,
  };
  const distinct = {
    ...weaker,
    link: "google:3",
    publisherLink: "https://example.org/liturgy",
    title: "A newly composed evening hymn for Inanna",
    decision: "ACCEPT_CONTEMPORARY_LITURGICAL",
    qualityScore: 80,
  };

  const clusters = rankAndClusterArticles([weaker, distinct, stronger], now);
  assert.equal(clusters.length, 2);
  assert.equal(clusters[0].representative.link, "google:2");
  assert.deepEqual(
    new Set(clusters[0].members.map((article) => article.link)),
    new Set(["google:1", "google:2"])
  );
  assert.ok(titleSimilarity(weaker.title, stronger.title) > 0.68);
});
