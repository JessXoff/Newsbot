import test from "node:test";
import assert from "node:assert/strict";
import {
  enrichArticle,
  extractArticleData,
  isSafeArticleUrl,
} from "../enrichArticles.js";

test("article extraction prefers substantive paragraphs and captures provenance", () => {
  const html = `
    <html><head>
      <title>Fallback title</title>
      <meta property="og:title" content="Museum publishes Ishtar catalogue">
      <meta name="author" content="Dr. Ada Example">
      <meta property="article:published_time" content="2026-08-15T12:00:00Z">
      <link rel="canonical" href="/catalogue">
    </head><body><nav><p>This navigation paragraph should not appear in evidence.</p></nav>
      <article>
        <p>This museum catalogue documents a newly conserved Ishtar relief and identifies its archaeological context in detail.</p>
        <p>The curators cite the excavation record, catalogue number, provenance history, and the scholars responsible for the translation.</p>
        <p>A third substantial paragraph supplies enough material for a conservative automated editorial assessment of the publication.</p>
        <p>A fourth substantial paragraph explains the institution's methodology and distinguishes evidence from modern interpretation.</p>
      </article>
    </body></html>`;
  const data = extractArticleData(html, "https://museum.example/news");

  assert.equal(data.canonicalUrl, "https://museum.example/catalogue");
  assert.equal(data.pageTitle, "Museum publishes Ishtar catalogue");
  assert.equal(data.author, "Dr. Ada Example");
  assert.equal(data.contentStatus, "ok");
  assert.doesNotMatch(data.excerpt, /navigation/);
});

test("unsafe publisher targets are rejected before fetching", () => {
  assert.equal(isSafeArticleUrl("https://example.com/article"), true);
  assert.equal(isSafeArticleUrl("http://127.0.0.1/private"), false);
  assert.equal(isSafeArticleUrl("http://169.254.169.254/latest/meta-data"), false);
  assert.equal(isSafeArticleUrl("file:///etc/passwd"), false);
});

test("successful URL decoding with an unavailable page preserves provenance for review", async () => {
  const article = { link: "https://news.google.com/rss/articles/test", title: "Test" };
  const enriched = await enrichArticle(article, {
    decoder: {
      decode: async () => ({ status: true, decoded_url: "https://example.com/story" }),
    },
    fetchPage: async () => {
      throw new Error("publisher blocked extraction");
    },
  });

  assert.equal(enriched.publisherLink, "https://example.com/story");
  assert.equal(enriched.enrichmentStatus, "partial");
  assert.match(enriched.enrichmentError, /blocked extraction/);
});
