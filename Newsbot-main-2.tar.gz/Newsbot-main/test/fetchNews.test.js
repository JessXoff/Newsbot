import test from "node:test";
import assert from "node:assert/strict";
import {
  fetchCandidateArticles,
  isRecentPublication,
  normalizeLink,
} from "../fetchNews.js";

test("publication-date filtering fails closed for stale and malformed dates", () => {
  const now = new Date("2026-08-16T00:00:00Z");
  assert.equal(isRecentPublication("2026-08-15T00:00:00Z", { now, maxAgeDays: 45 }), true);
  assert.equal(isRecentPublication("2026-01-01T00:00:00Z", { now, maxAgeDays: 45 }), false);
  assert.equal(isRecentPublication("not a date", { now, maxAgeDays: 45 }), false);
  assert.equal(isRecentPublication("2026-08-20T00:00:00Z", { now, maxAgeDays: 45 }), false);
});

test("RSS candidates are normalized, deduplicated, filtered, and newest-first", async () => {
  const now = new Date("2026-08-16T00:00:00Z");
  const parseUrl = async () => ({
    items: [
      {
        title: "Older current story",
        link: "https://news.google.com/rss/articles/one?oc=5",
        pubDate: "2026-08-10T00:00:00Z",
        source: "Museum",
        contentSnippet: "Evidence",
      },
      {
        title: "Newest story",
        link: "https://news.google.com/rss/articles/two?oc=5",
        pubDate: "2026-08-15T00:00:00Z",
        source: "University",
        contentSnippet: "Evidence",
      },
      {
        title: "Stale story",
        link: "https://news.google.com/rss/articles/old?oc=5",
        pubDate: "2020-01-01T00:00:00Z",
      },
    ],
  });

  const articles = await fetchCandidateArticles({ now, maxAgeDays: 45, parseUrl });
  assert.equal(articles.length, 2);
  assert.equal(articles[0].title, "Newest story");
  assert.equal(articles[1].title, "Older current story");
  assert.equal(articles[0].link.includes("?"), false);
  assert.equal(normalizeLink("not a URL"), "not a URL");
});
