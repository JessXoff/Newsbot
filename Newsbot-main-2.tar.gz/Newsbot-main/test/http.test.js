import test from "node:test";
import assert from "node:assert/strict";
import { fetchWithRetry } from "../http.js";

test("transient HTTP responses are retried with a bounded attempt count", async () => {
  let calls = 0;
  const response = await fetchWithRetry(
    "https://example.com",
    {},
    {
      fetchImpl: async () => {
        calls += 1;
        return new Response(calls === 1 ? "busy" : "ok", {
          status: calls === 1 ? 503 : 200,
        });
      },
      wait: async () => {},
      attempts: 3,
    }
  );

  assert.equal(response.status, 200);
  assert.equal(calls, 2);
});
