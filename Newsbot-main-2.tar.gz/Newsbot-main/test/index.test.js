import test from "node:test";
import assert from "node:assert/strict";
import { runBot } from "../index.js";

const environment = {
  ANTHROPIC_API_KEY: "test-key",
  DISCORD_WEBHOOK_URL: "https://discord.example/webhook",
};
const now = new Date("2026-08-16T12:00:00Z");

function state(overrides = {}) {
  return {
    seenLinks: new Set(),
    pendingArticles: [],
    postDate: "2026-08-16",
    postCount: 0,
    ...overrides,
  };
}

function candidate(index) {
  const titles = [
    "Museum publishes catalogue of a newly conserved temple tablet",
    "Composer releases an attributable contemporary dawn hymn",
    "University team translates a royal inscription from Nineveh",
  ];
  return {
    link: `https://news.google.com/story-${index}`,
    publisherLink: `https://publisher${index}.example/story-${index}`,
    title: titles[index],
    pubDate: `2026-08-${String(15 - index).padStart(2, "0")}T00:00:00Z`,
    source: `Source ${index}`,
    snippet: `Snippet ${index}`,
    excerpt: `Substantive evidence ${index}`,
    contentStatus: "ok",
    enrichmentStatus: "ok",
  };
}

function accepted(index) {
  return {
    index,
    decision: "ACCEPT_ACADEMIC",
    relevance: 5,
    credibility: 5,
    substance: 4,
    qualityScore: 90 - index,
    confidence: 0.95,
    crankRisk: false,
    riskSignals: [],
    reason: "grounded in a named academic source",
  };
}

const quietLogger = { log() {}, warn() {}, error() {} };

test("quota overflow remains pending instead of becoming permanently seen", async () => {
  const current = state();
  const articles = [candidate(0), candidate(1), candidate(2)];
  const posted = [];

  const result = await runBot({
    now,
    environment,
    load: async () => current,
    save: async () => {},
    fetchCandidates: async () => articles,
    enrichCandidates: async (items) => items,
    classify: async () => articles.map((_, index) => accepted(index)),
    post: async (article) => posted.push(article.link),
    logger: quietLogger,
  });

  assert.equal(result.posted, 2);
  assert.equal(current.pendingArticles.length, 1);
  assert.equal(current.seenLinks.size, 2);
  assert.equal(current.seenLinks.has(current.pendingArticles[0].link), false);
  assert.equal(posted.length, 2);
});

test("a webhook failure retains the accepted article for a later retry", async () => {
  const current = state();
  const article = candidate(0);
  let saves = 0;

  const result = await runBot({
    now,
    environment,
    load: async () => current,
    save: async () => {
      saves += 1;
    },
    fetchCandidates: async () => [article],
    enrichCandidates: async (items) => items,
    classify: async () => [accepted(0)],
    post: async () => {
      throw new Error("Discord unavailable");
    },
    logger: quietLogger,
  });

  assert.equal(result.posted, 0);
  assert.equal(current.pendingArticles.length, 1);
  assert.equal(current.seenLinks.has(article.link), false);
  assert.equal(saves, 1, "the pending decision is saved before delivery");
});

test("crank content is marked finished and never enters the posting queue", async () => {
  const current = state();
  const article = candidate(0);
  let postCalled = false;

  await runBot({
    now,
    environment,
    load: async () => current,
    save: async () => {},
    fetchCandidates: async () => [article],
    enrichCandidates: async (items) => items,
    classify: async () => [
      {
        ...accepted(0),
        decision: "REJECT_CRANK",
        credibility: 0,
        qualityScore: 0,
        reason: "promotes fabricated suppressed-history claims",
      },
    ],
    post: async () => {
      postCalled = true;
    },
    logger: quietLogger,
  });

  assert.equal(current.seenLinks.has(article.link), true);
  assert.deepEqual(current.pendingArticles, []);
  assert.equal(postCalled, false);
});

test("a full daily quota performs no paid or external editorial work", async () => {
  const current = state({ postCount: 2 });
  let fetched = false;
  const result = await runBot({
    now,
    environment,
    load: async () => current,
    save: async () => {},
    fetchCandidates: async () => {
      fetched = true;
      return [];
    },
    logger: quietLogger,
  });

  assert.equal(fetched, false);
  assert.equal(result.posted, 0);
});
