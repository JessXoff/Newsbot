import test from "node:test";
import assert from "node:assert/strict";
import { postArticle } from "../postToDiscord.js";

test("Discord posts use the publisher URL and tolerate malformed publication dates", async () => {
  const previousWebhook = process.env.DISCORD_WEBHOOK_URL;
  process.env.DISCORD_WEBHOOK_URL = "https://discord.example/api/webhooks/test";
  let request;
  try {
    await postArticle(
      {
        title: "A museum article",
        link: "https://news.google.com/story",
        publisherLink: "https://museum.example/story",
        source: "Museum",
        snippet: "A substantive catalogue article",
        pubDate: "not a date",
      },
      {
        fetchImpl: async (url, options) => {
          request = { url: url.toString(), options };
          return new Response("{}", { status: 200 });
        },
        wait: async () => {},
      }
    );
  } finally {
    if (previousWebhook === undefined) delete process.env.DISCORD_WEBHOOK_URL;
    else process.env.DISCORD_WEBHOOK_URL = previousWebhook;
  }

  const payload = JSON.parse(request.options.body);
  assert.match(request.url, /wait=true/);
  assert.equal(payload.embeds[0].url, "https://museum.example/story");
  assert.equal("timestamp" in payload.embeds[0], false);
});
