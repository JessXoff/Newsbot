import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { emptyState, loadState, parseState, saveState } from "../state.js";

function pendingArticle() {
  return {
    link: "https://news.google.com/story",
    publisherLink: "https://museum.example/story",
    title: "Museum story",
    pubDate: "2026-08-15T00:00:00Z",
    source: "Museum",
    snippet: "A catalogue announcement",
    decision: "ACCEPT_ACADEMIC",
    reason: "grounded in a catalogued artifact",
    relevance: 5,
    credibility: 5,
    substance: 4,
    qualityScore: 90,
    confidence: 0.95,
    discoveredAt: "2026-08-16T00:00:00Z",
  };
}

test("missing state starts clean while malformed state is fatal", async () => {
  const directory = await mkdtemp(join(tmpdir(), "newsbot-state-test-"));
  const target = join(directory, "state.json");
  try {
    assert.deepEqual(await loadState(target), emptyState());
    await writeFile(target, "{broken", "utf8");
    await assert.rejects(loadState(target), /invalid JSON/);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("atomic state saves round-trip pending delivery data", async () => {
  const directory = await mkdtemp(join(tmpdir(), "newsbot-state-test-"));
  const target = join(directory, "state.json");
  try {
    const state = {
      seenLinks: new Set(["https://news.google.com/seen"]),
      pendingArticles: [pendingArticle()],
      postDate: "2026-08-16",
      postCount: 1,
    };
    await saveState(state, target);
    const loaded = await loadState(target);

    assert.deepEqual(loaded, state);
    assert.match(await readFile(target, "utf8"), /"pendingArticles"/);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("legacy state without a pending queue migrates safely", () => {
  const parsed = parseState(
    JSON.stringify({ seenLinks: ["https://example.com/seen"], postDate: null, postCount: 0 })
  );
  assert.equal(parsed.seenLinks.size, 1);
  assert.deepEqual(parsed.pendingArticles, []);
});
